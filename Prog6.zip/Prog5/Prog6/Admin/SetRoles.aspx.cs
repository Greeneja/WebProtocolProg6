﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog5.Prog6
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                string role;
                role = "Admin";
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "Select UserName From Users where Role = '" + role + "'";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                SqlDataAdapter sda = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                DDLUsersForRole.DataSource = dt;
                DDLUsersForRole.DataBind();
                DDLUsersForRole.DataTextField = "UserName";
                DDLUsersForRole.DataValueField = "UserName";
                DDLUsersForRole.DataBind();
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "delete from Users where Username = '" + DDLUsers.SelectedValue.ToString() + "'";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                com.ExecuteNonQuery();
                conn.Close();

            }
            catch (Exception ex)
            {
                txtErrorMsg.Text = "Error: " + ex.Message;
            }
        }

        protected void btnRemoveRoleUser_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "update Users set Role = null where Username = '" + DDLUsers.SelectedValue.ToString() + "'";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                com.ExecuteNonQuery();
                conn.Close();
                txtErrorMsg.Text = DDLUsers.SelectedValue.ToString() + " removed from role: " + DDLRoles.SelectedValue.ToString();
            }
            catch (Exception ex)
            {
                txtErrorMsg.Text = "Error: " + ex.Message;
            }
        }

        protected void btnAddRoleUser_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "update Users set Role = '" + DDLRoles.SelectedValue.ToString() + "' where Username = '" + DDLUsers.SelectedValue.ToString() + "'";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                com.ExecuteNonQuery();
                conn.Close();
                txtErrorMsg.Text = DDLUsers.SelectedValue.ToString() + " changed to role: " + DDLRoles.SelectedValue.ToString();
            }
            catch (Exception ex)
            {
                txtErrorMsg.Text = "Error: " + ex.Message;
            }
        }

        protected void DDLRoles_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string role;
                role = DDLRoles.SelectedValue.ToString();
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "Select UserName From Users where Role = '" + role + "'";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                SqlDataAdapter sda = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                DDLUsersForRole.DataSource = dt;
                DDLUsersForRole.DataBind();
                DDLUsersForRole.DataTextField = "UserName";
                DDLUsersForRole.DataValueField = "UserName";
                DDLUsersForRole.DataBind();
                //com.ExecuteNonQuery();
                //conn.Close();
            }
            catch(Exception ex)
            {
                txtErrorMsg.Text = "Error: " + ex.Message;
            }
        }

        protected void btnAddRole_Click(object sender, EventArgs e)
        {
            try
            {
                ListItem item = new ListItem();
                item.Text = txtRole.Text;
                DDLRoles.Items.Add(item);
            }
            catch (Exception ex)
            {
                txtErrorMsg.Text = "Error: " + ex.Message;
            }
        }

        protected void btnRemoveRole_Click(object sender, EventArgs e)
        {
            try
            {
                string role;
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "update Users set Role = null where Role = '" + DDLRoles.SelectedValue.ToString() + "'";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                com.ExecuteNonQuery();
                conn.Close();
                role = DDLRoles.SelectedValue.ToString();
                DDLRoles.Items.RemoveAt(DDLRoles.SelectedIndex);
                txtErrorMsg.Text = role + " role removed";
            }
            catch (Exception ex)
            {
                txtErrorMsg.Text = "Error: " + ex.Message;
            }
        }
    }
}