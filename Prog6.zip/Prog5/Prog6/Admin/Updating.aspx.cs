﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog5.Prog6
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        private string[] keepIDs = new string[5] { "p101", "p103", "p107", "p109", "p201" };

        private int Prog3_Index
        {
            get
            {
                if (Session["Prog3_Index"] != null)
                {
                    return (int)Session["Prog3_Index"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["Prog3_Index"] = value; }
        }

        private int past_Index
        {
            get
            {
                if (Session["past_Index"] != null)
                {
                    return (int)Session["past_Index"];
                }
                else
                {
                    return 0;
                }
            }
            set { Session["past_Index"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void DetailsView1_ItemInserting(object sender, DetailsViewInsertEventArgs e)
        {
            try
            {
                TextBox theID = DetailsView1.Rows[0].Cells[1].Controls[0] as TextBox;
                TextBox Name = DetailsView1.Rows[1].Cells[1].Controls[0] as TextBox;
                TextBox Price = DetailsView1.Rows[2].Cells[1].Controls[0] as TextBox;
                TextBox Desc = DetailsView1.Rows[3].Cells[1].Controls[0] as TextBox;
                double newPriceDouble = double.Parse(Price.Text);
                if (txtMessage.Text != "ID already exists.")
                {
                    SqlDataSource1.InsertCommand = "insert into Product(ProductID, ProductName, UnitPrice, Description)" +
                        " values ('" + theID.Text + "', '" + Name.Text + "', " + newPriceDouble + ", '" + Desc.Text + "')";
                    txtMessage.Text = "Record Added.";
                }
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Product Not Added: " + ex.Message;
            }
        }

        protected void DetailsView1_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
        {
            try
            {
                string theID = DetailsView1.Rows[0].Cells[1].Text; //txtID.Text;
                TextBox newName = DetailsView1.Rows[1].Cells[1].Controls[0] as TextBox;
                TextBox newPrice = DetailsView1.Rows[2].Cells[1].Controls[0] as TextBox;
                TextBox newDesc = DetailsView1.Rows[3].Cells[1].Controls[0] as TextBox;
                double newPriceDouble = double.Parse(newPrice.Text);
                SqlDataSource1.UpdateCommand = "Update Product " +
                    "Set ProductName = '" + newName.Text + "', " +
                    "UnitPrice = " + newPriceDouble + ", " +
                    "Description = '" + newDesc.Text + "' " +
                    "Where ProductID = '" + theID + "'";
                txtMessage.Text = "Record updated.";
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Product Not Updated: " + ex.Message;
            }
        }

        protected void DetailsView1_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
        {
            DetailsView1.PageIndex = e.NewPageIndex;
            DetailsView1.DataBind();
        }

        protected void DetailsView1_ItemDeleting(object sender, DetailsViewDeleteEventArgs e)
        {
            bool deletable = true;
            try
            {
                string theID = DetailsView1.Rows[0].Cells[1].Text;
                for (int i = 0; i < keepIDs.Count(); i++)
                {
                    if (theID == keepIDs[i])
                    {
                        deletable = false;
                    }
                }
                if (deletable)
                {
                    SqlDataSource1.DeleteCommand = "Delete From Product " +
                        "Where ProductID ='" + theID + "'";
                    txtMessage.Text = "Record Deleted.";
                }
                else
                {
                    txtMessage.Text = "Record cannot be Deleted.";
                }
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Product Not Deleted: " + ex.Message;
            }
        }
    }
}