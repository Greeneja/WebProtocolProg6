﻿using prog4.Prog5.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog5
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        private List<shoppingBag> bagList
        {
            get
            {
                if (Session["bagList"] == null)
                {
                    Session["bagList"] = new List<shoppingBag>();
                }
                return (List<shoppingBag>)Session["bagList"];
            }
            set { Session["bagList"] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["bagList"] != null)
            {
                //ProductGrid.DataSource = bagList;
                //ProductGrid.DataBind();
                DataTable dataTable = new DataTable();
                DataColumn dataColumn;
                dataColumn = new DataColumn("ProdID");
                dataTable.Columns.Add(dataColumn);
                dataColumn = new DataColumn("ProdName");
                dataTable.Columns.Add(dataColumn);
                dataColumn = new DataColumn("ProdPrice");
                dataTable.Columns.Add(dataColumn);
                dataColumn = new DataColumn("ProdQty");
                dataTable.Columns.Add(dataColumn);
                dataColumn = new DataColumn("ProdCost");
                dataTable.Columns.Add(dataColumn);

                foreach (shoppingBag itm in bagList)
                {
                    DataRow dataRow = dataTable.NewRow();
                    dataRow[0] = itm.getProdID();
                    dataRow[1] = itm.getProdName();
                    dataRow[2] = itm.getProdPrice();
                    dataRow[3] = itm.getProdQty();
                    dataRow[4] = itm.getProdSubtotal();

                    dataTable.Rows.Add(dataRow);
                }
                ProductGrid.DataSource = dataTable;
                ProductGrid.DataBind();//Bind datatable
            }
        }

        protected void btnCheckout_Click(object sender, EventArgs e)
        {
            Session["bagList"] = null;
            Response.Redirect("~/prog5/login.aspx");
        }
    }
}