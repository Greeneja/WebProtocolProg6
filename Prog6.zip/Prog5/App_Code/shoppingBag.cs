﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace prog4.Prog5.App_Code
{
    public class shoppingBag
    {
        protected string prodID;
        protected string prodName;
        protected double prodPrice;
        protected int prodQty;
        protected double prodSubtotal;
        public shoppingBag(string ID, string name, double price, int qty, double subtotal)
        {
            prodID = ID;
            prodName = name;
            prodPrice = price;
            prodQty = qty;
            prodSubtotal = subtotal;
        }

        public string getProdID()
        {
            return prodID;
        }

        public string getProdName()
        {
            return prodID;
        }

        public double getProdPrice()
        {
            return prodPrice;
        }

        public int getProdQty()
        {
            return prodQty;
        }

        public double getProdSubtotal()
        {
            return prodSubtotal;
        }
    }
}