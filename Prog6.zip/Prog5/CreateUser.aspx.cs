﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace prog4.Prog5
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string checkUser = "Select count(*) From Users where Username = '" + txtUersname.Text + "'";
                SqlCommand com = new SqlCommand(checkUser, conn);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
                if (temp == 1)
                {
                    Response.Write("user already exists");
                }
                conn.Close();
            }
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UsersConnectionString"].ConnectionString);
                conn.Open();
                string insertQuery = "insert into Users(Username, Password, Email, City, Role)" +
                    " values (@uName, @uPass, @uEmail, @uCity, @uRole)";
                SqlCommand com = new SqlCommand(insertQuery, conn);
                com.Parameters.AddWithValue("@uName", txtUersname.Text);
                com.Parameters.AddWithValue("@uPass", txtPassword.Text);
                com.Parameters.AddWithValue("@uEmail", txtEmail.Text);
                com.Parameters.AddWithValue("@uCity", txtCity.Text);
                com.Parameters.AddWithValue("@uRole", "Member");
                com.ExecuteNonQuery();
                conn.Close();
                
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.Message);
            }
            Response.Redirect("~/Prog5/Login.aspx");
        }
    }
}